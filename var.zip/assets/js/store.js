import {createStore} from 'redux'

const store = {data: 1};
export default store;
