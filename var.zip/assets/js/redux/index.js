import {combineReducers} from 'redux'
import {cartItemsReducer} from "./reducer";

export default combineReducers({ cartItemsReducer });
