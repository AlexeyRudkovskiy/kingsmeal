<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/dashboard' => [[['_route' => 'dashboard', '_controller' => 'App\\Controller\\DashboardController::index'], null, null, null, false, false, null]],
        '/dashboard/order' => [[['_route' => 'order_index', '_controller' => 'App\\Controller\\OrderController::index'], null, ['GET' => 0], null, true, false, null]],
        '/dashboard/order/unprocessed' => [[['_route' => 'order_unprocessed', '_controller' => 'App\\Controller\\OrderController::newOrders'], null, ['GET' => 0], null, false, false, null]],
        '/dashboard/order/new' => [[['_route' => 'order_new', '_controller' => 'App\\Controller\\OrderController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/' => [[['_route' => 'prod', '_controller' => 'App\\Controller\\ProdController::index'], null, null, null, false, false, null]],
        '/dashboard/products' => [[['_route' => 'product_index', '_controller' => 'App\\Controller\\ProductController::index'], null, ['GET' => 0], null, true, false, null]],
        '/dashboard/products/new' => [[['_route' => 'product_new', '_controller' => 'App\\Controller\\ProductController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/dashboard/(?'
                    .'|order/([^/]++)(?'
                        .'|(*:38)'
                        .'|/edit(*:50)'
                        .'|(*:57)'
                    .')'
                    .'|products/([^/]++)(?'
                        .'|(*:85)'
                        .'|/(?'
                            .'|edit(*:100)'
                            .'|variant(?'
                                .'|(*:118)'
                                .'|/(?'
                                    .'|new(*:133)'
                                    .'|([^/]++)(?'
                                        .'|(*:152)'
                                        .'|/edit(*:165)'
                                        .'|(*:173)'
                                    .')'
                                .')'
                            .')'
                        .')'
                        .'|(*:185)'
                    .')'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => 'order_show', '_controller' => 'App\\Controller\\OrderController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        50 => [[['_route' => 'order_edit', '_controller' => 'App\\Controller\\OrderController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        57 => [[['_route' => 'order_delete', '_controller' => 'App\\Controller\\OrderController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        85 => [[['_route' => 'product_show', '_controller' => 'App\\Controller\\ProductController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        100 => [[['_route' => 'product_edit', '_controller' => 'App\\Controller\\ProductController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        118 => [[['_route' => 'product_variant_index', '_controller' => 'App\\Controller\\ProductVariantController::index'], ['product_id'], ['GET' => 0], null, true, false, null]],
        133 => [[['_route' => 'product_variant_new', '_controller' => 'App\\Controller\\ProductVariantController::new'], ['product_id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        152 => [[['_route' => 'product_variant_show', '_controller' => 'App\\Controller\\ProductVariantController::show'], ['product_id', 'id'], ['GET' => 0], null, false, true, null]],
        165 => [[['_route' => 'product_variant_edit', '_controller' => 'App\\Controller\\ProductVariantController::edit'], ['product_id', 'id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        173 => [[['_route' => 'product_variant_delete', '_controller' => 'App\\Controller\\ProductVariantController::delete'], ['product_id', 'id'], ['DELETE' => 0], null, false, true, null]],
        185 => [
            [['_route' => 'product_delete', '_controller' => 'App\\Controller\\ProductController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
