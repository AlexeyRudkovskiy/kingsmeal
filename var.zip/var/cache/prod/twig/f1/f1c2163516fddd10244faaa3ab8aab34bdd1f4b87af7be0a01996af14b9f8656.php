<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* admin.html.twig */
class __TwigTemplate_a59b30ed3bca20a2b0b05e7fb6c3a74499ecd2fb70df995ba382523d715192f3 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $context["current_path"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "request", [], "any", false, false, false, 1), "get", [0 => "_route"], "method", false, false, false, 1);
        // line 2
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\">
    <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <link href=\"https://fonts.googleapis.com/css?family=Roboto:400,500,700&display=swap&subset=cyrillic\" rel=\"stylesheet\">

    ";
        // line 9
        echo $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("admin");
        echo "
    ";
        // line 10
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 11
        echo "</head>
<body>
<div class=\"grid admin-container\">
    <div class=\"admin-sidebar\">
        <div class=\"admin-section-header\">
            <span class=\"project-name\">KingsMeal</span>
        </div>
        <nav class=\"nav-section\">
            <span class=\"nav-header\">Товары</span>
            ";
        // line 20
        ob_start(function () { return ''; });
        // line 21
        echo "            <a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product_index");
        echo "\" class=\"nav-item ";
        if (0 === twig_compare(($context["current_path"] ?? null), "product_index")) {
            echo "active";
        }
        echo "\">
                Все товары
                ";
        // line 23
        if (1 === twig_compare(twig_get_attribute($this->env, $this->source, ($context["kingsmeal"] ?? null), "productsCount", [], "any", false, false, false, 23), 0)) {
            echo "<span class=\"nav-item-badge\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["kingsmeal"] ?? null), "productsCount", [], "any", false, false, false, 23), "html", null, true);
            echo "</span>";
        }
        // line 24
        echo "            </a>
            ";
        $___internal_0e05e21cfa021be2551c47cdde0957d0e82ca64577d9573bf4ecb27d9757e83b_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 20
        echo twig_spaceless($___internal_0e05e21cfa021be2551c47cdde0957d0e82ca64577d9573bf4ecb27d9757e83b_);
        // line 26
        echo "            <a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product_new");
        echo "\" class=\"nav-item ";
        if (0 === twig_compare(($context["current_path"] ?? null), "product_new")) {
            echo "active";
        }
        echo "\">Добавить товар</a>
        </nav>
        <nav class=\"nav-section\">
            <span class=\"nav-header\">Заказы</span>
            ";
        // line 30
        ob_start(function () { return ''; });
        // line 31
        echo "            <a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("order_index");
        echo "\" class=\"nav-item ";
        if (0 === twig_compare(($context["current_path"] ?? null), "order_index")) {
            echo "active";
        }
        echo "\">
                Все заказы
                ";
        // line 33
        if (1 === twig_compare(twig_get_attribute($this->env, $this->source, ($context["kingsmeal"] ?? null), "productsCount", [], "any", false, false, false, 33), 0)) {
            echo "<span class=\"nav-item-badge\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["kingsmeal"] ?? null), "productsCount", [], "any", false, false, false, 33), "html", null, true);
            echo "</span>";
        }
        // line 34
        echo "            </a>
            ";
        $___internal_acdcfe29db48aeb9895be4dbd083539c0d7b3171142aa8189da86fe20da2e72c_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 30
        echo twig_spaceless($___internal_acdcfe29db48aeb9895be4dbd083539c0d7b3171142aa8189da86fe20da2e72c_);
        // line 36
        echo "            ";
        ob_start(function () { return ''; });
        // line 37
        echo "            <a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("order_unprocessed");
        echo "\" class=\"nav-item ";
        if (0 === twig_compare(($context["current_path"] ?? null), "order_unprocessed")) {
            echo "active";
        }
        echo "\">
                Новые заказы
                ";
        // line 39
        if (1 === twig_compare(twig_get_attribute($this->env, $this->source, ($context["kingsmeal"] ?? null), "productsCount", [], "any", false, false, false, 39), 0)) {
            echo "<span class=\"nav-item-badge\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["kingsmeal"] ?? null), "productsCount", [], "any", false, false, false, 39), "html", null, true);
            echo "</span>";
        }
        // line 40
        echo "            </a>
            ";
        $___internal_1687d91cfe022b78e07dc4cc666ff7152edb485ae0711abd5454fc206b13b828_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 36
        echo twig_spaceless($___internal_1687d91cfe022b78e07dc4cc666ff7152edb485ae0711abd5454fc206b13b828_);
        // line 42
        echo "        </nav>
        <nav class=\"nav-section\">
            <span class=\"nav-header\">testing</span>
            <a href=\"javascript:\" class=\"nav-item\">Item 1</a>
            <a href=\"javascript:\" class=\"nav-item\">Item 2<span class=\"nav-item-badge\">10+</span></a>
            <a href=\"javascript:\" class=\"nav-item\">Item 3</a>
        </nav>
    </div>
    <div class=\"admin-content\">
        <div class=\"admin-section-header\">
            <nav class=\"admin-header-navigation\">
";
        // line 54
        echo "            </nav>
        </div>
        <div class=\"admin-section-content\">
            <div class=\"buttons-group\">
                <a href=\"javascript:\" class=\"button\"><span class=\"icon\">👨</span>hello world</a>
                <a href=\"javascript:\" class=\"button\"><span class=\"icon\">🎅</span>hello world</a>
            </div>
            ";
        // line 61
        $this->displayBlock('body', $context, $blocks);
        // line 62
        echo "        </div>
    </div>
</div>
";
        // line 65
        echo $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("admin");
        echo "
";
        // line 66
        $this->displayBlock('javascripts', $context, $blocks);
        // line 67
        echo "</body>
</html>
";
    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Admin Dashboard";
    }

    // line 10
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 61
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 66
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    public function getTemplateName()
    {
        return "admin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  217 => 66,  211 => 61,  205 => 10,  198 => 6,  192 => 67,  190 => 66,  186 => 65,  181 => 62,  179 => 61,  170 => 54,  157 => 42,  155 => 36,  151 => 40,  145 => 39,  135 => 37,  132 => 36,  130 => 30,  126 => 34,  120 => 33,  110 => 31,  108 => 30,  96 => 26,  94 => 20,  90 => 24,  84 => 23,  74 => 21,  72 => 20,  61 => 11,  59 => 10,  55 => 9,  49 => 6,  43 => 2,  41 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "admin.html.twig", "G:\\Projects\\PhpStormProjects\\kingsmeal\\templates\\admin.html.twig");
    }
}
